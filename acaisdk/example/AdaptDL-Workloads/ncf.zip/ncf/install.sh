# For simple dependencies
pip install -r requirements.txt

## For pytorch 1.0.1 dependency
#wget -q https://download.pytorch.org/whl/cu100/torch-1.0.1-cp36-cp36m-linux_x86_64.whl
#pip install torch-1.0.1-cp36-cp36m-linux_x86_64.whl
#rm -f torch-1.0.1-cp36-cp36m-linux_x86_64.whl
