from preprocess_squad import preprocess
import json
import sys
import argparse

# invoke this function as:
# python preprocess.py ./inputFolder/


# parse argparse argument for hyperparam tuning
parser = argparse.ArgumentParser()
parser.add_argument('inPath', nargs='?', type=str, help="input folder for raw dataset")
args = parser.parse_args()

inputPath = args.inPath


# preprocess / load data data
train, dev = preprocess(path=inputPath, newPrepocess=True)
